#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#run python main optimization script by:
#python3 XXXX.py

#need right packages by (check first by pip list to see if installed)
#sudo apt install python3-pip
#pip install scipy		for optimization
#pip install pandas		for reading in data file
#pip install matplotlib

#How to replace lines:
#os_string = "sed -i '25 s/.*/endTime         " + str(x_test[0]) + ";/' controlDictTest"
#os.system(os_string)
#-i will replace file, 25 is the line number, s means substitute, / is first delimiter, .* gets all line content, / is second delimiter, xx is #what to replace, / is third delimiter, controlDictTest is the file to replace

#------- Import Modules ------------

import os
import scipy
from scipy import integrate
import numpy
import pandas
import matplotlib.pyplot as plt
import csv
from decimal import Decimal

total_run_time = 70e-6

os.system("rm output_results.csv") #to re-start csv file every time

#------- Script Parameters ------------

output_csv_file = 'output_results.csv'
csv_open = open(output_csv_file,'a',encoding='UTF8',newline='') #open csv (use'a' for append mode so can write each line at a time
writer = csv.writer(csv_open)
writer.writerow(['Bubble Thickness (m)','Bubble Pressure (atm)','Bubble Temperature (K)','End Flow Rate (pL)','Expansion Time (s)','Collapse Time (s)'])
csv_open.close() #close the csv file writing	

count = 1

#------- Execute the Allrun Bash Script ------------

#os.system("./Allrun")

#------- Define Functions to Use ------------

def round_nearest(num: float, to: float) -> float:
    num, to = Decimal(str(num)), Decimal(str(to))
    return float(round(num / to) * to)
    
def find_expansion_point(time,short_leg_holder):
    value_min = numpy.nanmin(short_leg_holder)
    index_expansion = numpy.where(short_leg_holder == value_min)
    index_expansion = index_expansion[0][0]
    return round_nearest(time[index_expansion],0.5e-6)

def find_collapse_point(time,short_leg_holder,long_leg_holder):

    value_min = numpy.nanmin(short_leg_holder)
    index_expansion = numpy.where(short_leg_holder == value_min)
    index_expansion = index_expansion[0][0]
    
    value_expansion = short_leg_holder[index_expansion]
    resistor_length = numpy.absolute(long_leg_holder[0] - short_leg_holder[0])
    resistor_middle = short_leg_holder[0] + resistor_length/2
    in_range_distance = short_leg_holder > resistor_middle
    in_range_time = time > time[index_expansion]
    possible_values = in_range_distance & in_range_time
    
    first_value = numpy.where(possible_values == 1)
    first_value = first_value[0][0]
    time_val = time[first_value]
    location_val = short_leg_holder[first_value]

    time_val = round_nearest(time_val,0.5e-6)
    return time_val,location_val
    
def get_time_and_bubble_values(directory):

    my_list = os.listdir(directory)
    time_folder_holder = numpy.zeros(len(my_list))
    for i in range(len(my_list)): #go through all the directories
        time_folder_holder[i] = float(my_list[i])

    indices = numpy.argsort(time_folder_holder) #get indicies of sorted array order

    time_holder = time_folder_holder[indices]
    short_leg_holder = numpy.array([])
    long_leg_holder = numpy.array([])
    for i in range(len(my_list)):
        current_folder = my_list[indices[i]]
        data_file = os.path.join(directory,current_folder,'plane.xy')
        starting_line = 1
        x = numpy.array([])
        y = numpy.array([])
        z = numpy.array([])
        alpha_val = numpy.array([])
        with open(data_file) as f:
            for line in f:
                data_line = line.split()
                if starting_line == 1:
                    starting_line = starting_line + 1
                    continue
                x_num = float(data_line[0])
                y_num = float(data_line[1])
                z_num = float(data_line[2])
                alpha_num = float(data_line[3])

                x = numpy.append(x,x_num)
                y = numpy.append(y,y_num)
                z = numpy.append(z,z_num)
                alpha_val = numpy.append(alpha_val,alpha_num)
        locs = alpha_val < 0.5
        if numpy.sum(locs) == 0:
            short_leg_holder = numpy.append(short_leg_holder,float('nan'))
            long_leg_holder = numpy.append(long_leg_holder,float('nan'))
        else:
            short_leg_holder = numpy.append(short_leg_holder,numpy.min(y[locs]))
            long_leg_holder = numpy.append(long_leg_holder,numpy.max(y[locs]))       
    return time_holder,short_leg_holder,long_leg_holder
        
def get_and_order_times_and_flowrate(directory):

    my_list = os.listdir(directory)
    time_folder_holder = numpy.zeros(len(my_list))
    for i in range(len(my_list)): #go through all the directories
        time_folder_holder[i] = float(my_list[i])

    indices = numpy.argsort(time_folder_holder) #get indicies of sorted array order

    time_holder = numpy.empty(0)
    flowrate_holder = numpy.empty(0)
    for i in range(len(my_list)):
        current_folder = my_list[indices[i]]
        data_file = os.path.join(directory,current_folder,'surfaceFieldValue.dat')
        data = pandas.read_csv(data_file,delimiter='\t',skiprows=4)
        time = data.values[0:-1,0]
        flowrate = data.values[0:-1,1]
        time_holder = numpy.append(time_holder,time)
        flowrate_holder = numpy.append(flowrate_holder,flowrate)

    cumulative_flowrate = integrate.cumtrapz(flowrate_holder,time_holder) #m^3
    cumulative_flowrate_pL = cumulative_flowrate*(1/(1e-6))*(1e-3)*(1/(1e-12)) #pL
    time_holder = time_holder[0:len(time_holder)-1] #since integration will be one less than the time vector

    return time_holder, cumulative_flowrate_pL
    
def plot_cumulative_flowrate(time,cumulative_flowrate_pL): #if I want to plot data
	
    plt.rc('xtick',labelsize=30)
    plt.rc('ytick',labelsize=30)
    plt.rc('font',weight='bold')	
    plt.xlabel(r'Time ($\mu$s)',fontsize=30, fontweight='bold')
    plt.ylabel(r'Cumulative Flowrate (pL)',fontsize=30, fontweight='bold')	
    plt.errorbar(time_exp,flow_exp,yerr=dflow_exp,marker='.',markerfacecolor='black',markersize=10,label='Experiment')
    plt.plot(time*1e6,cumulative_flowrate_pL,label='OpenFOAM')	
    plt.legend(loc='best',fontsize=30)
    plt.grid(alpha=.5)
    plt.show()

def objective_function_openFOAM(x): #main objective function to minimize squared sum error

#Variable Formatting:
# x[0] --> bubble thickness (0.5 um)
# x[1] --> bubble pressure (100 atm)
# x[2] --> bubble temperature (573 K)
    
    global count #so can access global variable count and modify it
    postProcess_sample_directory = r"postProcessing/sampleDict_plane/"
            
    ## ------ Find Bubble Max Expansion Point ------ ##
    
    #modify setFieldsDict
    os_string = "sed -i '25 s/.*/bubble_height " + str(x[0]) + ";/' system/setFieldsDict"
    os.system(os_string)
    os_string = "sed -i '27 s/.*/p_select " + str(x[1]) + ";/' system/setFieldsDict"
    os.system(os_string)
    os_string = "sed -i '28 s/.*/T_select " + str(x[2]) + ";/' system/setFieldsDict"
    os.system(os_string)		
    
    #modify snappyHexMesh
    os_string = "sed -i '23 s/.*/bubble_height " + str(x[0]) + ";/' system/snappyHexMeshDict"
    os.system(os_string)	
    
    #modify controlDict_expansion
    os_string = "sed -i '25 s/.*/endTime         " + str(total_run_time/3) + ";/' system/controlDict_expansion"
    os.system(os_string)		
    
    os.system("./Allrun") #run the case
    time_holder,short_leg_holder,long_leg_holder = get_time_and_bubble_values(postProcess_sample_directory)
    expansion_time = find_expansion_point(time_holder,short_leg_holder)
    
    ## ------ Find Bubble Collapse Point ------ ##	
    
    #modify controlDict_expansion
    os_string = "sed -i '25 s/.*/endTime         " + str(expansion_time) + ";/' system/controlDict_expansion"
    os.system(os_string)		
    
    #modify controlDict_collapse
    os_string = "sed -i '25 s/.*/endTime         " + str(total_run_time/2) + ";/' system/controlDict_collapse"
    os.system(os_string)	
    
    os.system("./Allrun2") #run the case
    time_holder,short_leg_holder,long_leg_holder = get_time_and_bubble_values(postProcess_sample_directory)
    time_val,location_val = find_collapse_point(time_holder,short_leg_holder,long_leg_holder)
    
    ## ------ Re-Run with Proper Collapse Point Set ------ ##	
    
    #modify controlDict_collapse
    os_string = "sed -i '25 s/.*/endTime         " + str(time_val) + ";/' system/controlDict_collapse"
    os.system(os_string)	
            
    os.system("./Allrun3") #run the case	
    
    ## ------ Process Results to Fit to Experimental Data ------ ##		
    
    postProcess_directory = r"postProcessing/triSurfaceVolumetricFlowRate/"
    time, cumulative_flowrate_pL = get_and_order_times_and_flowrate(postProcess_directory)
    #plot_cumulative_flowrate(time,cumulative_flowrate_pL)
        
    csv_open = open(output_csv_file,'a',encoding='UTF8',newline='') #open csv (use'a' for append mode so can write each line at a time
    writer = csv.writer(csv_open)
    writer.writerow([x[0],x[1],x[2],cumulative_flowrate_pL[-1],expansion_time,time_val])	
    csv_open.close() #close the csv file writing		
                    
    count = count + 1
    return None

#------- Perform Main Code ------------

x_initial = [0.5e-6,100.48,589] #initial condctions based on good simulation so less iterations
objective_function_openFOAM(x_initial)









	
